# Build SPA app
pushd $(pwd)/src/Web/WebSPA
npm rebuild node-sass
#npm run build:prod
