﻿namespace eShopOnContainers.Core.Models.Navigation
{
    public class TabParameter
    {
        public int TabIndex { get; set; }
    }
}