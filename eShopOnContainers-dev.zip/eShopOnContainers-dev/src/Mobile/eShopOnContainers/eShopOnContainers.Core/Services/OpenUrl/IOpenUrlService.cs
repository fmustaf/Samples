﻿namespace eShopOnContainers.Core.Services.OpenUrl
{
    public interface IOpenUrlService
    {
        void OpenUrl(string url);
    }
}
