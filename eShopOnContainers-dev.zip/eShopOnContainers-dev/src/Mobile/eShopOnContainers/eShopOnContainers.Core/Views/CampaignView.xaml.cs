﻿namespace eShopOnContainers.Core.Views
{
    using Xamarin.Forms;

    public partial class CampaignView: ContentPage
    {

        public CampaignView()
        {
            InitializeComponent();
        }
    }
}