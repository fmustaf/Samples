﻿using Xamarin.Forms;

namespace eShopOnContainers.Core.Views.Templates
{
    public partial class BasketItemTemplate : ContentView
    {
        public BasketItemTemplate()
        {
            InitializeComponent();
        }
    }
}