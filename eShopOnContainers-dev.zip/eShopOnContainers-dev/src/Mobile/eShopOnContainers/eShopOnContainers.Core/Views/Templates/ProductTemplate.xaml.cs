﻿using Xamarin.Forms;

namespace eShopOnContainers.Core.Views.Templates
{
    public partial class ProductTemplate : ContentView
    {
        public ProductTemplate()
        {
            InitializeComponent();
        }
    }
}